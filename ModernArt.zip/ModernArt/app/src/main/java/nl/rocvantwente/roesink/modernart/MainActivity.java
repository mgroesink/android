package nl.rocvantwente.roesink.modernart;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {

    // Declare variables for the layout views
    private ImageView imageView1;
    private ImageView imageView2;
    private ImageView imageView3;
    private ImageView imageView4;
    private ImageView imageView5;
    private SeekBar sbColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set the base colors for the imageviews
        imageView1 = (ImageView)findViewById(R.id.imageView1);
        imageView2 = (ImageView)findViewById(R.id.imageView2);
        imageView3 = (ImageView)findViewById(R.id.imageView3);
        imageView4 = (ImageView)findViewById(R.id.imageView4);
        imageView5 = (ImageView)findViewById(R.id.imageView5);
        imageView1.setBackgroundColor(Color.argb(0xFF, 0, 0, 200));
        imageView2.setBackgroundColor(Color.argb(0xFF, 255, 255, 255)); // white
        imageView3.setBackgroundColor(Color.argb(0xFF, 0, 200, 0));
        imageView4.setBackgroundColor(Color.argb(0xFF, 128 , 128, 128)); //grey
        imageView5.setBackgroundColor(Color.argb(0xFF, 100 , 0, 0));

        sbColor = (SeekBar)findViewById(R.id.seekBar);
        sbColor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change the color of the non-white and non-grey imageviews
                imageView1.setBackgroundColor(Color.argb(0xFF, progress, progress, 200));
                imageView3.setBackgroundColor(Color.argb(0xFF, progress, 200 , progress));
                imageView5.setBackgroundColor(Color.argb(0xFF, 100 , progress, progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up imageView, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        // Check the menu option that is chosen by the user
        if (id == R.id.action_settings) {
            // Create a alert dialog
            new AlertDialog.Builder(this)
                    .setMessage(R.string.dialog_message)
                    .setNegativeButton(R.string.negative_text, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // do nothing
                        }
                    })
                    .setPositiveButton(R.string.positive_text, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            Intent iBrowser = new Intent(Intent.ACTION_VIEW ,
                                    Uri.parse("http://www.moma.org/"));
                            startActivity(iBrowser);
                        }
                    })
                    .show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
